# RPC measurements

These are same-host measurements. Successful-request latency excludes failed requests; errors and unsent requests are reported separately.

Success rate follows requests planned in each phase until their final state; QPS counts successful completions whose completion time falls within that phase. Quantiles use nearest rank on raw per-run successful latency samples. No per-second P95 averaging.

Generator validity requires zero unsent/mismatched/dropped rows and scheduling P99 <=20ms outside warmup. Invalid runs are excluded from A/B conclusions.

| Run | Mode | Service | Phase | Sent | Unsent | Success % | Success QPS | P95 ms | P99 ms | Scheduling P99 ms | Valid |
|---|---|---|---|---:|---:|---:|---:|---:|---:|---:|---|
| ab-isolated-1 | isolated | fast | healthy | 500 | 0 | 100.00 | 100.00 | 1.91 | 3.87 | 0.19 | True |
| ab-isolated-1 | isolated | slow | healthy | 100 | 0 | 100.00 | 20.00 | 203.08 | 204.47 | 0.23 | True |
| ab-isolated-1 | isolated | fast | overload | 1500 | 0 | 100.00 | 100.00 | 1.30 | 3.20 | 0.36 | True |
| ab-isolated-1 | isolated | slow | overload | 1800 | 0 | 38.89 | 39.73 | 2759.53 | 2762.14 | 0.30 | True |
| ab-isolated-1 | isolated | fast | recovery | 500 | 0 | 100.00 | 100.00 | 1.09 | 3.15 | 0.55 | True |
| ab-isolated-1 | isolated | slow | recovery | 100 | 0 | 99.00 | 40.00 | 2562.18 | 2602.66 | 0.52 | True |
| ab-isolated-2 | isolated | fast | healthy | 500 | 0 | 100.00 | 100.00 | 2.78 | 4.22 | 0.20 | True |
| ab-isolated-2 | isolated | slow | healthy | 100 | 0 | 100.00 | 20.00 | 202.68 | 203.80 | 0.16 | True |
| ab-isolated-2 | isolated | fast | overload | 1500 | 0 | 100.00 | 100.00 | 1.12 | 2.33 | 0.39 | True |
| ab-isolated-2 | isolated | slow | overload | 1800 | 0 | 38.89 | 39.73 | 2760.67 | 2765.51 | 0.23 | True |
| ab-isolated-2 | isolated | fast | recovery | 500 | 0 | 100.00 | 100.00 | 1.53 | 3.70 | 0.26 | True |
| ab-isolated-2 | isolated | slow | recovery | 100 | 0 | 99.00 | 40.00 | 2562.40 | 2604.29 | 1.14 | True |
| ab-isolated-3 | isolated | fast | healthy | 500 | 0 | 100.00 | 100.00 | 3.98 | 7.28 | 1.91 | True |
| ab-isolated-3 | isolated | slow | healthy | 100 | 0 | 100.00 | 20.00 | 205.52 | 207.16 | 0.70 | True |
| ab-isolated-3 | isolated | fast | overload | 1500 | 0 | 100.00 | 100.00 | 1.45 | 3.31 | 0.34 | True |
| ab-isolated-3 | isolated | slow | overload | 1800 | 0 | 38.89 | 39.73 | 2763.93 | 2768.20 | 0.39 | True |
| ab-isolated-3 | isolated | fast | recovery | 500 | 0 | 100.00 | 100.00 | 1.13 | 2.54 | 0.23 | True |
| ab-isolated-3 | isolated | slow | recovery | 100 | 0 | 99.00 | 40.00 | 2564.71 | 2602.77 | 0.24 | True |
| ab-shared-1 | shared | fast | healthy | 500 | 0 | 100.00 | 100.00 | 2.82 | 4.51 | 0.28 | True |
| ab-shared-1 | shared | slow | healthy | 100 | 0 | 100.00 | 20.00 | 203.25 | 204.05 | 0.26 | True |
| ab-shared-1 | shared | fast | overload | 1500 | 0 | 73.53 | 67.33 | 1386.21 | 1395.13 | 0.34 | True |
| ab-shared-1 | shared | slow | overload | 1800 | 0 | 72.61 | 79.20 | 1581.38 | 1589.76 | 0.50 | True |
| ab-shared-1 | shared | fast | recovery | 500 | 0 | 99.60 | 118.20 | 1134.40 | 1257.30 | 0.72 | True |
| ab-shared-1 | shared | slow | recovery | 100 | 0 | 99.00 | 43.60 | 1316.72 | 1459.25 | 0.25 | True |
| ab-shared-2 | shared | fast | healthy | 500 | 0 | 100.00 | 100.00 | 3.20 | 4.88 | 0.21 | True |
| ab-shared-2 | shared | slow | healthy | 100 | 0 | 100.00 | 20.00 | 204.05 | 204.62 | 0.40 | True |
| ab-shared-2 | shared | fast | overload | 1500 | 0 | 73.40 | 67.33 | 1394.61 | 1398.19 | 0.19 | True |
| ab-shared-2 | shared | slow | overload | 1800 | 0 | 72.72 | 79.20 | 1590.28 | 1592.72 | 0.33 | True |
| ab-shared-2 | shared | fast | recovery | 500 | 0 | 99.60 | 117.80 | 1171.40 | 1268.03 | 0.14 | True |
| ab-shared-2 | shared | slow | recovery | 100 | 0 | 99.00 | 44.00 | 1371.43 | 1470.48 | 0.15 | True |
| ab-shared-3 | shared | fast | healthy | 500 | 0 | 100.00 | 100.00 | 2.66 | 4.65 | 0.28 | True |
| ab-shared-3 | shared | slow | healthy | 100 | 0 | 100.00 | 20.00 | 203.12 | 205.49 | 0.24 | True |
| ab-shared-3 | shared | fast | overload | 1500 | 0 | 75.20 | 69.27 | 1392.08 | 1403.50 | 0.29 | True |
| ab-shared-3 | shared | slow | overload | 1800 | 0 | 72.83 | 79.20 | 1588.57 | 1599.16 | 0.17 | True |
| ab-shared-3 | shared | fast | recovery | 500 | 0 | 99.60 | 117.40 | 1192.88 | 1337.78 | 0.31 | True |
| ab-shared-3 | shared | slow | recovery | 100 | 0 | 99.00 | 44.40 | 1394.24 | 1517.77 | 0.17 | True |
| fast-only-isolated | isolated | fast | healthy | 500 | 0 | 100.00 | 100.00 | 2.22 | 3.67 | 0.18 | True |
| fast-only-isolated | isolated | fast | overload | 1500 | 0 | 100.00 | 100.00 | 1.43 | 3.07 | 0.12 | True |
| fast-only-isolated | isolated | fast | recovery | 500 | 0 | 100.00 | 100.00 | 1.58 | 2.62 | 0.45 | True |
| fast-only-shared | shared | fast | healthy | 500 | 0 | 100.00 | 100.00 | 2.83 | 3.57 | 0.16 | True |
| fast-only-shared | shared | fast | overload | 1500 | 0 | 100.00 | 100.00 | 1.49 | 3.49 | 0.25 | True |
| fast-only-shared | shared | fast | recovery | 500 | 0 | 100.00 | 100.00 | 1.66 | 2.96 | 0.14 | True |
| healthy-isolated | isolated | fast | healthy | 500 | 0 | 100.00 | 100.00 | 3.44 | 5.61 | 15.81 | True |
| healthy-isolated | isolated | slow | healthy | 100 | 0 | 100.00 | 20.00 | 204.54 | 211.38 | 0.69 | True |
| healthy-isolated | isolated | fast | overload | 1500 | 0 | 100.00 | 100.00 | 1.64 | 3.18 | 0.31 | True |
| healthy-isolated | isolated | slow | overload | 300 | 0 | 100.00 | 20.00 | 202.68 | 204.06 | 0.53 | True |
| healthy-isolated | isolated | fast | recovery | 500 | 0 | 100.00 | 100.00 | 1.38 | 3.28 | 0.30 | True |
| healthy-isolated | isolated | slow | recovery | 100 | 0 | 100.00 | 20.00 | 202.61 | 204.60 | 0.30 | True |
| healthy-shared | shared | fast | healthy | 500 | 0 | 100.00 | 100.00 | 2.88 | 4.87 | 0.20 | True |
| healthy-shared | shared | slow | healthy | 100 | 0 | 100.00 | 20.00 | 203.26 | 206.93 | 0.17 | True |
| healthy-shared | shared | fast | overload | 1500 | 0 | 100.00 | 100.00 | 1.28 | 2.92 | 0.30 | True |
| healthy-shared | shared | slow | overload | 300 | 0 | 100.00 | 20.00 | 201.96 | 203.67 | 0.75 | True |
| healthy-shared | shared | fast | recovery | 500 | 0 | 100.00 | 100.00 | 0.86 | 2.06 | 0.12 | True |
| healthy-shared | shared | slow | recovery | 100 | 0 | 100.00 | 20.00 | 201.20 | 204.15 | 0.20 | True |
| multi-isolated | isolated | fast | healthy | 500 | 0 | 100.00 | 100.00 | 3.04 | 4.71 | 0.28 | True |
| multi-isolated | isolated | slow | healthy | 100 | 0 | 100.00 | 20.00 | 203.43 | 204.08 | 0.20 | True |
| multi-isolated | isolated | fast | overload | 1500 | 0 | 100.00 | 100.00 | 1.57 | 3.74 | 0.36 | True |
| multi-isolated | isolated | slow | overload | 1800 | 0 | 38.89 | 39.73 | 2763.01 | 2766.25 | 0.52 | True |
| multi-isolated | isolated | fast | recovery | 500 | 0 | 100.00 | 100.00 | 1.60 | 2.85 | 0.23 | True |
| multi-isolated | isolated | slow | recovery | 100 | 0 | 99.00 | 40.00 | 2563.88 | 2596.65 | 0.13 | True |
| multi-shared | shared | fast | healthy | 500 | 0 | 100.00 | 100.00 | 2.05 | 3.70 | 0.21 | True |
| multi-shared | shared | slow | healthy | 100 | 0 | 100.00 | 20.00 | 202.08 | 203.74 | 0.28 | True |
| multi-shared | shared | fast | overload | 1500 | 0 | 71.93 | 66.00 | 1403.35 | 1430.68 | 0.73 | True |
| multi-shared | shared | slow | overload | 1800 | 0 | 72.83 | 79.20 | 1598.71 | 1604.41 | 0.39 | True |
| multi-shared | shared | fast | recovery | 500 | 0 | 99.60 | 117.40 | 1196.11 | 1335.65 | 0.28 | True |
| multi-shared | shared | slow | recovery | 100 | 0 | 99.00 | 44.40 | 1391.53 | 1520.90 | 0.78 | True |
| swap-isolated | isolated | fast | healthy | 500 | 0 | 100.00 | 100.00 | 2.43 | 4.51 | 0.14 | True |
| swap-isolated | isolated | slow | healthy | 100 | 0 | 100.00 | 20.00 | 204.52 | 205.94 | 0.17 | True |
| swap-isolated | isolated | fast | overload | 1500 | 0 | 100.00 | 100.00 | 0.99 | 3.40 | 0.14 | True |
| swap-isolated | isolated | slow | overload | 1800 | 0 | 38.89 | 39.73 | 2762.50 | 2766.12 | 0.15 | True |
| swap-isolated | isolated | fast | recovery | 500 | 0 | 100.00 | 100.00 | 0.80 | 2.31 | 0.29 | True |
| swap-isolated | isolated | slow | recovery | 100 | 0 | 99.00 | 40.00 | 2561.40 | 2596.08 | 0.23 | True |
| swap-shared | shared | fast | healthy | 500 | 0 | 100.00 | 100.00 | 2.25 | 4.44 | 0.20 | True |
| swap-shared | shared | slow | healthy | 100 | 0 | 100.00 | 20.00 | 202.85 | 205.12 | 0.39 | True |
| swap-shared | shared | fast | overload | 1500 | 0 | 73.00 | 67.13 | 1399.92 | 1428.16 | 0.21 | True |
| swap-shared | shared | slow | overload | 1800 | 0 | 72.89 | 79.20 | 1596.33 | 1606.79 | 0.23 | True |
| swap-shared | shared | fast | recovery | 500 | 0 | 99.60 | 117.20 | 1194.84 | 1363.49 | 0.10 | True |
| swap-shared | shared | slow | recovery | 100 | 0 | 99.00 | 44.60 | 1397.33 | 1563.48 | 0.39 | True |

## Repeated matched A/B (per-run medians and ranges)

| Parameters | Mode | Runs | Success QPS median [min,max] | P95 ms median [min,max] | Success % median |
|---|---|---:|---|---|---:|
| (100.0, 120.0, 20.0, 128, 1, 3000, 512, 3, 5, 15, 5, False, 'slow-overload') | isolated | 3 | 100.00 [100.00,100.00] | 1.30 [1.12,1.45] | 100.00 |
| (100.0, 120.0, 20.0, 128, 1, 3000, 512, 3, 5, 15, 5, False, 'slow-overload') | shared | 3 | 67.33 [67.33,69.27] | 1392.08 [1386.21,1394.61] | 73.53 |

Matched median per-run P95 change: 99.91% (not a pooled quantile).
| (100, 0, 0, 128, 1, 3000, 512, 3, 5, 15, 5, False, 'fast-only') | isolated | 1 | 100.00 [100.00,100.00] | 1.43 [1.43,1.43] | 100.00 |
| (100, 0, 0, 128, 1, 3000, 512, 3, 5, 15, 5, False, 'fast-only') | shared | 1 | 100.00 [100.00,100.00] | 1.49 [1.49,1.49] | 100.00 |
| (100, 20, 20, 128, 1, 3000, 512, 3, 5, 15, 5, False, 'healthy') | isolated | 1 | 100.00 [100.00,100.00] | 1.64 [1.64,1.64] | 100.00 |
| (100, 20, 20, 128, 1, 3000, 512, 3, 5, 15, 5, False, 'healthy') | shared | 1 | 100.00 [100.00,100.00] | 1.28 [1.28,1.28] | 100.00 |
| (100.0, 120.0, 20, 128, 4, 3000, 512, 3, 5, 15, 5, False, 'slow-overload') | isolated | 1 | 100.00 [100.00,100.00] | 1.57 [1.57,1.57] | 100.00 |
| (100.0, 120.0, 20, 128, 4, 3000, 512, 3, 5, 15, 5, False, 'slow-overload') | shared | 1 | 66.00 [66.00,66.00] | 1403.35 [1403.35,1403.35] | 71.93 |
| (100.0, 120.0, 20, 128, 1, 3000, 512, 3, 5, 15, 5, True, 'slow-overload') | isolated | 1 | 100.00 [100.00,100.00] | 0.99 [0.99,0.99] | 100.00 |
| (100.0, 120.0, 20, 128, 1, 3000, 512, 3, 5, 15, 5, True, 'slow-overload') | shared | 1 | 67.13 [67.13,67.13] | 1399.92 [1399.92,1399.92] | 73.00 |

## JMH

| Run | Mode | Metric | Threads | Payload | Score | Unit | Success QPS |
|---|---|---|---:|---:|---:|---|---:|
| jmh-isolated-16-1024-sample/fork-1 | isolated | sample | 16 | 1024 | 2.13 | ms/op | N/A |
| jmh-isolated-16-1024-throughput/fork-1 | isolated | thrpt | 16 | 1024 | 8.81 | ops/ms | 8811.76 |
| jmh-isolated-16-128-sample/fork-1 | isolated | sample | 16 | 128 | 1.31 | ms/op | N/A |
| jmh-isolated-16-128-throughput/fork-1 | isolated | thrpt | 16 | 128 | 11.71 | ops/ms | 11714.43 |
| jmh-isolated-64-1024-sample/fork-1 | isolated | sample | 64 | 1024 | 6.24 | ms/op | N/A |
| jmh-isolated-64-1024-throughput/fork-1 | isolated | thrpt | 64 | 1024 | 10.06 | ops/ms | 10055.02 |
| jmh-isolated-64-128-sample/fork-1 | isolated | sample | 64 | 128 | 3.94 | ms/op | N/A |
| jmh-isolated-64-128-throughput/fork-1 | isolated | thrpt | 64 | 128 | 15.05 | ops/ms | 15050.72 |
| jmh-shared-16-1024-sample/fork-1 | shared | sample | 16 | 1024 | 1.94 | ms/op | N/A |
| jmh-shared-16-1024-throughput/fork-1 | shared | thrpt | 16 | 1024 | 8.42 | ops/ms | 8423.41 |
| jmh-shared-16-128-sample/fork-1 | shared | sample | 16 | 128 | 1.26 | ms/op | N/A |
| jmh-shared-16-128-throughput/fork-1 | shared | thrpt | 16 | 128 | 12.15 | ops/ms | 12147.74 |
| jmh-shared-64-1024-sample/fork-1 | shared | sample | 64 | 1024 | 6.52 | ms/op | N/A |
| jmh-shared-64-1024-throughput/fork-1 | shared | thrpt | 64 | 1024 | 10.00 | ops/ms | 9997.14 |
| jmh-shared-64-128-sample/fork-1 | shared | sample | 64 | 128 | 4.17 | ms/op | N/A |
| jmh-shared-64-128-throughput/fork-1 | shared | thrpt | 64 | 128 | 16.04 | ops/ms | 16036.99 |

JMH is closed-loop and SampleTime is sampled; it does not establish fixed-arrival tail latency. Error, overload, timeout or mismatched response fails a normal benchmark.

## Cleanup and recovery

- ab-isolated-1: statuses={'success': 3759, 'overloaded': 1101}, pending=0, timers=0, project threads=0, sampled queue peaks={'fast': 0, 'slow': 100}, recovery=3s (three consecutive 1s cohorts, success >=99%, successful P95 <=100ms).
- ab-isolated-2: statuses={'success': 3759, 'overloaded': 1101}, pending=0, timers=0, project threads=0, sampled queue peaks={'fast': 0, 'slow': 100}, recovery=3s (three consecutive 1s cohorts, success >=99%, successful P95 <=100ms).
- ab-isolated-3: statuses={'success': 3759, 'overloaded': 1101}, pending=0, timers=0, project threads=0, sampled queue peaks={'fast': 0, 'slow': 100}, recovery=3s (three consecutive 1s cohorts, success >=99%, successful P95 <=100ms).
- ab-shared-1: statuses={'success': 3967, 'overloaded': 893}, pending=0, timers=0, project threads=0, sampled queue peaks={'fast': 200, 'slow': 200}, recovery=5s (three consecutive 1s cohorts, success >=99%, successful P95 <=100ms).
- ab-shared-2: statuses={'success': 3967, 'overloaded': 893}, pending=0, timers=0, project threads=0, sampled queue peaks={'fast': 200, 'slow': 200}, recovery=5s (three consecutive 1s cohorts, success >=99%, successful P95 <=100ms).
- ab-shared-3: statuses={'success': 3996, 'overloaded': 864}, pending=0, timers=0, project threads=0, sampled queue peaks={'fast': 200, 'slow': 200}, recovery=5s (three consecutive 1s cohorts, success >=99%, successful P95 <=100ms).
- fast-only-isolated: statuses={'success': 2800}, pending=0, timers=0, project threads=0, sampled queue peaks={'fast': 0, 'slow': 0}, recovery=3s (three consecutive 1s cohorts, success >=99%, successful P95 <=100ms).
- fast-only-shared: statuses={'success': 2800}, pending=0, timers=0, project threads=0, sampled queue peaks={'fast': 0, 'slow': 0}, recovery=3s (three consecutive 1s cohorts, success >=99%, successful P95 <=100ms).
- healthy-isolated: statuses={'success': 3360}, pending=0, timers=0, project threads=0, sampled queue peaks={'fast': 0, 'slow': 0}, recovery=3s (three consecutive 1s cohorts, success >=99%, successful P95 <=100ms).
- healthy-shared: statuses={'success': 3360}, pending=0, timers=0, project threads=0, sampled queue peaks={'fast': 0, 'slow': 0}, recovery=3s (three consecutive 1s cohorts, success >=99%, successful P95 <=100ms).
- multi-isolated: statuses={'success': 3759, 'overloaded': 1101}, pending=0, timers=0, project threads=0, sampled queue peaks={'fast': 0, 'slow': 100}, recovery=3s (three consecutive 1s cohorts, success >=99%, successful P95 <=100ms).
- multi-shared: statuses={'success': 3947, 'overloaded': 913}, pending=0, timers=0, project threads=0, sampled queue peaks={'fast': 199, 'slow': 199}, recovery=5s (three consecutive 1s cohorts, success >=99%, successful P95 <=100ms).
- swap-isolated: statuses={'success': 3759, 'overloaded': 1101}, pending=0, timers=0, project threads=0, sampled queue peaks={'fast': 100, 'slow': 0}, recovery=3s (three consecutive 1s cohorts, success >=99%, successful P95 <=100ms).
- swap-shared: statuses={'success': 3964, 'overloaded': 896}, pending=0, timers=0, project threads=0, sampled queue peaks={'fast': 200, 'slow': 200}, recovery=5s (three consecutive 1s cohorts, success >=99%, successful P95 <=100ms).

One-second queue samples can miss transient peaks. Tests enforce the queue bound directly. Static isolation can leave capacity unused when only one service is busy; this experiment does not imply higher total throughput or production performance.
